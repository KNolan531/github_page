// Assignment 3 - CS 3305 - Section 01 
// by: Kevin Nolan 
//------------------------------------ 
// This program implements project 2 from Chapter 5 of the textbook. 
//
//Ver 1.0 - 2/18/2020
// Project #2: Deleting repetitions from a linked list of items function has been created 
//Ver 2.0 - 2/19/2020 
// Created test list in Main and successfully ran the delete_repetitions function  


#include "node1.h"
#include <iostream>

using namespace main_savitch_5; 

// This function deletes nodes that contain similar items so no repetitions exist in the list. 
// Pre-Condition: List is not empty  
// Post-Condition: List has been reduced to only have 1 copy of each item and no repetitions! 
void deleteRepetitions(node*& head_ptr)
{
	node* current = head_ptr;
	node* previous = current;
	node* cursor = current;

	while (current != NULL)
	{
		previous = cursor;
		cursor = current->link();

		while (cursor != NULL)
		{
			if (current->data() == cursor->data())
			{
				list_remove(previous);
				cursor = previous->link();
			}
			else
			{
				previous = cursor;
				cursor = cursor->link();
			}

		}
		current = current->link();
	}
	
}

int main()
{
    std::cout << "Testing the delete repetitions function!!!\n";

	node *head_list = new node(9); 
	node* cursor = head_list; 
	
	list_insert(cursor, 8);
	cursor = cursor->link();
	list_insert(cursor, 6); 
	cursor = cursor->link();
	list_insert(cursor, 4); 
	cursor = cursor->link();
	list_insert(cursor, 9); 
	cursor = cursor->link();
	list_insert(cursor, 5); 
	cursor = cursor->link();
	list_insert(cursor, 6); 
	cursor = cursor->link();
	list_insert(cursor, 8); 
	cursor = cursor->link();
	list_insert(cursor, 1); 
	cursor = cursor->link();
	list_insert(cursor, 8); 
	cursor = cursor->link();
	list_insert(cursor, 2);

	cursor = head_list; 
	std::cout << "\n My original list: \n";

	while (cursor != NULL)
	{
		
		std::cout << cursor->data() << "\t"; 
		cursor = cursor->link(); 
	}

	deleteRepetitions(head_list); 
	
	cursor = head_list;
	std::cout << "\n My list after deleting repetitions: \n";
	while (cursor != NULL)
	{
		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	list_clear(head_list); 

	head_list = new node(15);
	cursor = head_list; 

	list_insert(cursor, 28); 
	cursor = cursor->link(); 
	list_insert(cursor, 15); 
	cursor = cursor->link(); 
	list_insert(cursor, 88); 
	cursor = cursor->link(); 
	list_insert(cursor, 22);
	cursor = cursor->link();
	list_insert(cursor, 41);
	cursor = cursor->link();
	list_insert(cursor, 22);

	std::cout << "\n \n ------------------------------------- " << "\n My new list: \n" ; 
	cursor = head_list;
	while (cursor != NULL)
	{
		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	deleteRepetitions(head_list); 

	

	cursor = head_list;
	std::cout << "\n My list after deleting repetitions: \n";
	while (cursor != NULL)
	{
		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	std::cout << "\n"; 	   	  
}








