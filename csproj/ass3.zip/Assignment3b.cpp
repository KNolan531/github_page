// Assignment 3 - CS 3305 - Section 01 
// by: Kevin Nolan 
//------------------------------------ 
// This program implements project 7 from Chapter 5 of the textbook. 
//
//Ver 1.0 - 2/21/2020
// Project #7: sorting_list from a linked list of items function has been created 
//Ver 2.0 - 2/22/2020 
// Created test list in Main and successfully ran the sort_list function  

#include "node1.h"
#include <iostream>

using namespace main_savitch_5;

//This function sorts a list from smallest to largest
//Pre-Condition: head_ptr is not null 
//Post-Condition: The nodes have been sorted in ascending order. 
void sort_list(node*& head_ptr)
{
	node* cursor = head_ptr;
	node* previous = cursor;
	node* second = NULL; //new node used to store ordered list 
	
	node::value_type max = 0;

	while (head_ptr != NULL)
	{
		while (cursor != NULL)
		{
			if (cursor->data() > max)
				max = cursor->data();

			cursor = cursor->link();

		}

		cursor = head_ptr;
		previous = cursor;

		while (cursor != NULL)
		{
			if (cursor->data() == max)
			{
				list_head_insert(second, max);

				if (cursor == head_ptr)
					list_head_remove(head_ptr);
				else
					list_remove(previous);

				cursor = NULL;
			}
			else
			{
				previous = cursor;
				cursor = cursor->link();
			}

		}

		cursor = head_ptr;
		max = 0;
	}
		
	head_ptr = second;
	   
}


int main()
{
	std::cout << "Testing my sort_list function!!\n";

	node* head_list = new node(9);
	node* cursor = head_list;


	list_insert(cursor, 8);
	cursor = cursor->link();
	list_insert(cursor, 6);
	cursor = cursor->link();
	list_insert(cursor, 4);
	cursor = cursor->link();
	list_insert(cursor, 9);
	cursor = cursor->link();
	list_insert(cursor, 5);
	cursor = cursor->link();
	list_insert(cursor, 6);
	cursor = cursor->link();
	list_insert(cursor, 8);
	cursor = cursor->link();
	list_insert(cursor, 1);
	cursor = cursor->link();
	list_insert(cursor, 8);
	cursor = cursor->link();
	list_insert(cursor, 2);

	cursor = head_list;
	std::cout << "\n My original list: \n";

	while (cursor != NULL)
	{

		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	sort_list(head_list); //calling sort method 
	std::cout << "\n My list after sorting: \n";

	cursor = head_list;

	while (cursor != NULL)
	{
		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	list_clear(head_list);
	head_list = new node(15);
	cursor = head_list;

	list_insert(cursor, 28);
	cursor = cursor->link();
	list_insert(cursor, 15);
	cursor = cursor->link();
	list_insert(cursor, 88);
	cursor = cursor->link();
	list_insert(cursor, 22);
	cursor = cursor->link();
	list_insert(cursor, 41);
	cursor = cursor->link();
	list_insert(cursor, 22);

	std::cout << "\n \n ------------------------------------- " << "\n My new list: \n";
	cursor = head_list;
	while (cursor != NULL)
	{
		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	sort_list(head_list); //calling sort method 
	std::cout << "\n After calling sort_list function: \n";

	cursor = head_list;

	while (cursor != NULL)
	{
		std::cout << cursor->data() << "\t";
		cursor = cursor->link();
	}

	std::cout << "\n";

}



