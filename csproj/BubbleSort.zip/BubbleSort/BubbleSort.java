package Sort;
import java.util.Random; 
import java.util.Scanner; 

/* BubbleSort Class: 
 * Program primarily used as a test program to show Bubble Sort method 
 *  is properly sorting the elements in ascending order. The code is then re-used later on 
 *  in BubbleTimer class also in the Sort package. 
 *   
 *  By: Kevin Nolan  - CSE 2300 
 */


public class BubbleSort {


	

/* bubbleSort Method: 
 * Method takes each element and swaps them side by side until array is sorted. 
 * @param: an integer array provided by user to be sorted.  
 * 
 */
public void bubbleSort(int [] array)
	{ 
		
		int temp = 0; 
		
		for(int i =0; i < array.length -1 ; i++ ) 
			for (int j = i +1; j < array.length; j++) 
			{ 
				if(array[i] > array[j])
				{ 
				temp = array[i]; 
				array[i] = array[j]; 
				array[j] = temp; 
				 
				}
				
			}
		
	}
	
	

public static void main (String [] args) 
{ 
	 
	Scanner scan = new Scanner(System.in);
	Random r = new Random(); //used to generate random numbers
	BubbleSort b = new BubbleSort();
	int n; //value of array size 
	
	System.out.println("Please enter the size of the array:"); 
	n = scan.nextInt(); 
	
	
	int [] array = new int[n]; //declares value of array length 
	
	for(int i = 0; i < n; i++) 
	{ 
		array[i] = r.nextInt(500); 
	}
	
	for(int i = 0; i < n; i++) 
		System.out.println(array[i]);
	
	
	b.bubbleSort(array); 
	
	System.out.println("Sorted: " + "\n"); 
	for(int i = 0; i < n; i++) 
		System.out.println(array[i]);
	
	
}
	
	
	
	
}
