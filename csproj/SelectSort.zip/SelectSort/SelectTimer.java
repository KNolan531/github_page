package Sort;
import java.util.Scanner; 
import java.util.Random; 

/* SelectTimer Class: 
 * Program uses select sort algorithm to sort arrays of size n as input 
 * by the user in the console 1000 times. It gets the start and end time of these sorts and 
 * determines the average time it takes the computer to process the sort method in milli-seconds. It 
 * then prints it out to the user. 
 *
 *  By: Kevin Nolan - CSE 2300 
 */

public class SelectTimer {
	
	
	/* selecSort Method: 
	 * Method goes through array starting with 1st element and finds smallest value and places it in  
	 * the first element, then increments to next element until all values are in order.  Code was previously 
	 * tested in the SelectSort class. 
	 * @param: an integer array provided by user to be sorted.  
	*/
	public static void selecSort(int [] array) 
	{ 
		for(int i =0; i < array.length; i++) 
		{ 
			int min = i; 
			int temp = 0; 
			for(int j = i +1; j < array.length; j++)
			{
				if(array[j] < array[min]) 
					min = j; 
			}
			
			if( i != min &&  min < array.length) 
			{ 
				temp = array[min]; 
				array[min] = array[i]; 
				array[i] = temp; 
								
			}
			
		}
	}
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		Random r = new Random(); 
		int n; //number of array size input by user 
		int num_iterations = 1000; //number of iterations through 
		long running_time = 0; //default running value
		long total_time = 0; //default total time 
		
		
		
		System.out.println("Enter number of elements to sort in array: "); 
		n = sc.nextInt(); 
		
		int [] array = new int[n]; 
		
		
		/* The following for loop iterates through num_iterations and fills each array with 
		 * random values up to n*10 using the Random class method nextInt. It then gets the current system time as
		 * start time in milli-seconds, calls the selecSort() static method and then gets the current system time as 
		 * end time in milli-seconds. Finally it calculates the running time and adds it to total.  
		 */
		for(int i = 0; i < num_iterations; i++ ) 
		{
			for(int j = 0; j < n; j++) 
				array[j] = r.nextInt(n*10);  
			long start_time = System.currentTimeMillis(); 
			selecSort(array); 
			long end_time = System.currentTimeMillis(); 
			
			
			running_time =  (end_time - start_time); 
			total_time += running_time; 
		}
		
		double average = (total_time / (double)num_iterations); //average value as a double to get exact decimal number 
	
		System.out.println("Array Size: " + "" + n);
		System.out.println("Select Sort sorted a total of :  " + (n *1000) + " items!"); //prints out total # of elements sorted 
	    System.out.println("Average running time for each array in Select Sort = "+ average + " miliseconds");
		
		
		
		

	}

}
