package Sort;
import java.util.Random; 
import java.util.Scanner; 

/* SelectSort Class: 
 * Program primarily used as a test program to show Select Sort method 
 *  is properly sorting the elements in ascending order. It prompts the user to 
 *  enter a number of array size and then creates and sorts an array of that size. It prints out the
 *  original array to the user and then the sorted array to the user. 
 *  
 *  By: Kevin Nolan - CSE 2300 
 */

public class SelectSort {
	
	
	
/* selectSort Method: 
 * Method goes through array starting with 1st element and finds smallest value and places it in  
 *  the first element, then increments to next element until all values are in order.  
 * @param: an integer array provided by user to be sorted.  
*/
	
	public void selectSort(int [] array) 
	{ 
		for(int i =0; i < array.length; i++) 
		{ 
			int min = i; 
			int temp = 0; 
			for(int j = i +1; j < array.length; j++)
			{
				if(array[j] < array[min]) 
					min = j; 
			}
			
			if( i != min &&  min < array.length) 
			{ 
				temp = array[min]; 
				array[min] = array[i]; 
				array[i] = temp; 
								
			}
			
		}
		
	}
	
	
	
	
	

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Random r = new Random(); //used to generate random numbers
		SelectSort s = new SelectSort(); 
		int n;
		
		System.out.println("Please enter the size of the array:"); 
		n = scan.nextInt(); 
		
		
		int [] array = new int[n]; //declares value of array length 
		
		for(int i = 0; i < n; i++) 
		{ 
			array[i] = r.nextInt(500); 
		}
		
		for(int i = 0; i < n; i++) 
			System.out.println(array[i]);
		
		
		s.selectSort(array); 
		
		System.out.println("Sorted: " + "\n"); 
		for(int i = 0; i < n; i++) 
			System.out.println(array[i]);
		
		
		
		
		
	}

}
