#include "bintree.h"
#include "build_tree.h"
#include <iostream>
#include <cassert>
#include <cstdlib>

using namespace std;

template <class T>
void printItem(T item)
{
    cout<<item<<" ";
}

//#1 - Depth Function 
template <class T> 
int depth(binary_tree_node<T>* root)
{
	if (root == NULL)
		return -1;
	else
	{
		int left_side = depth(root->left()); 
		int right_side = depth(root->right()); 

		if (right_side > left_side)
			return 1 + right_side;
		else
			return 1 + left_side; 
	}		
}

//#2 - Max Function 
template <class T>
T max(binary_tree_node<T>* root)
{
	if (root == NULL)
		return 0;
	else
	{
		T max_root = root->data();
		T max_right = max(root->right());
		T max_left = max(root->left());

		if (max_root > max_left && max_root > max_right)
			return max_root;
		else if (max_left > max_root&& max_left > max_right)
			return max_left;
		else
			return max_right; 
			
	}
}

//#3 - Sum Function
template <class T>
double tree_sum(binary_tree_node<T>* root)
{
	if (root == NULL)
		return 0;
	else
	{
		double sum = root->data(); 
		sum += tree_sum(root->left()); 
		sum += tree_sum(root->right());

		return sum; 
	}
}

//#4 - Average Function 
template <class T>
double tree_average(binary_tree_node<T>* root)
{
	if (root == NULL)
		return 0;
	else
	{
		double sum = root->data();
		sum += tree_sum(root->left());
		sum += tree_sum(root->right());

		return sum / tree_size(root);
	}

}

//#5 - isBalanced Function
template <class T>
bool tree_is_balanced(binary_tree_node<T>* root)
{
	if (root == NULL)
		return true;
	else
	{
		if (abs(depth(root->left()) - depth(root->right()) <= 1))
		{
			if(tree_is_balanced(root->left()) && tree_is_balanced(root->right()))
				return true;
		}

	}
	return false; 
}
	


int main() {
    binary_tree_node<int> *s1 = sample1();
	cout << "The depth of s1 is: " << depth(s1) << endl; 
	cout << "The max of s1 is: " << max(s1) << endl;
	cout << "The sum of s1 is: " << tree_sum(s1) << endl;
	cout << "The average of s1 is: " << tree_average(s1) << endl;
	cout << "Is s1 balanced? " << tree_is_balanced(s1) << endl; 
    print(s1, 0);

    cout<<endl;    
    
    inorder(printItem<int>, s1);
    cout<<endl;    
        
    preorder(printItem<int>, s1);
    cout<<endl;    
        
    postorder(printItem<int>, s1);
    cout<<endl;    
    
    binary_tree_node<int> *s2 = sample2();
	cout << "\n The depth of s2 is: " << depth(s2) << endl;
	cout << "The max of s2 is: " << max(s2) << endl;
	cout << "The sum of s2 is: " << tree_sum(s2) << endl;
	cout << "The average of s2 is: " << tree_average(s2) << endl;
	cout << "Is s2 balanced? " << tree_is_balanced(s2) << endl;
    print(s2, 0);
    cout<<endl;
    
    inorder(printItem<int>, s2);
    cout<<endl;    
        
    preorder(printItem<int>, s2);
    cout<<endl;    
        
    postorder(printItem<int>, s2);
    cout<<endl;   


	binary_tree_node<double>* s3 = sample3();
	cout << "\n The depth of s3 is: " << depth(s3) << endl;
	cout << "The max of s3 is: " << max(s3) << endl;
	cout << "The sum of s3 is: " << tree_sum(s3) << endl;
	cout << "The average of s3 is: " << tree_average(s3) << endl;
	cout << "Is s3 balanced? " << tree_is_balanced(s3) << endl;
	cout << "\n";
	cout << endl;

	binary_tree_node<double>* s4 = sample4();
	cout << "\n The depth of s4 is: " << depth(s4) << endl;
	cout << "The max of s4 is: " << max(s4) << endl;
	cout << "The sum of s4 is: " << tree_sum(s4) << endl;
	cout << "The average of s4 is: " << tree_average(s4) << endl;
	cout << "Is s4 balanced? " << tree_is_balanced(s4) << endl;
	cout << "\n";
	cout << endl;
	


    


}
