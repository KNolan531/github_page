package listsTests;

import java.util.NoSuchElementException;

public class DataStructureException extends NoSuchElementException {
	
	public DataStructureException(String e) 
	{ 
		super(); 
	}

}
