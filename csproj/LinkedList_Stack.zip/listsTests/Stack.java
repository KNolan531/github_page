/* Stack Class 
 * by: Kevin Nolan 
 * 
 * This class implements a stack by using the LinkedList implementation with 
 * various methods to add,delete and look at the top of the stack. 
 */

package listsTests;

public class Stack extends LinkedList {
	
	//Looks at top of the stack, will throw the Exception if Stack is empty! 
	public int peek() throws DataStructureException 
	{ 
		Node top = head; 
				
		if(top == null) 
			throw new DataStructureException("Invalid request! Stack is empty!!");  
		else
			return head.getData();  
	}
	
	//Adds to top of stack by using head of linked list. 
	public void push(int value) 
	{ 
		Node n = new Node(value); 
		
		n.setNext(head); 
		head = n; 
		numOfItems++; 
	
	}
	
	//Deletes from top of Stack via the head of list. 
	public int pop() throws DataStructureException
	{ 
		int deleted = 0; 		
		if(numOfItems == 0) 
			throw new DataStructureException("Invalid request! Stack is empty!!");
		else 
		{	
			deleted = head.getData(); 
			head = head.getNext(); 
			numOfItems--; 
			return deleted; 
			
		} 	
		
		
	}
	
	
	
	
	

}
