/* Linked List Class 
 * by: Kevin Nolan 
 * 
 * This class implements a linked list from scratch with various methods to manipulate the list. 
 */

package listsTests;

public class LinkedList  {

	protected Node head; //start of list
	protected int numOfItems; 
	
	
	LinkedList() 
	{ 
		head = null; 
		numOfItems = 0; 
	}
	
	//Returns # of items in the list. 
	public int getNumOfItems() 
	{ 
		return numOfItems; 
	}
	
	//Adds int value to the front of the list and sets previous head to the next value in list. 
	public void add(int value) 
	{ 
		Node n2 = new Node(value); 
		n2.setNext(head); 
		head = n2; 
		numOfItems++; 
		
	}
	
	//Deletes the int value from the list by iterating through, returns false if value is not found, true otherwise. 
	public boolean delete(int value) 
	{ 
		Node current = head; 
		Node previous = null; 
		
		while(current != null && current.getData() != value) 
		{ 
			previous = current; 
			current = current.getNext(); 
			
		}
		
		if(current == null) 
			return false; 
		else 
		{ 
			if(current == head) 
				head = current.getNext(); 
			else 
			{ 
			previous.setNext(current);
			numOfItems--; 
			return true; 
			}
		} 
		
		return true; 
		
		
		
	}
	
	//A simple method that iterates through the list,adds each value and returns the sum. 
	public int getSum() 
	{ 
		int sum = 0; 
		
		Node current = head; 
		
		while(current != null) 
		{ 
			sum += current.getData(); 
			current = current.getNext(); 
		}
		
		return sum; 
	}
	
	//Starts at the head and tries to find the value v and returns count, the position in the list or -1 if not found. 
	public int findValue(int v) 
	{ 
		Node current = head; 
		int count = 0; 
		
		while(current != null) 
		{ 
			if(current.getData() == v) 
				return count; 
			else
			{
				current = current.getNext(); 
				count++; 
			}	
		}
		
		return -1; 
	}
	
	//Prints out the contents of the list starting at the head. If numOfItems = 0 then nothing will print. 
	public void printList() 
	{ 
		Node current = head; 
		
		for(int i = 0; i < numOfItems; i++) 
		{
			System.out.println(current.getData());
			current = current.getNext(); 
		}
	}
	
	
	
	
	
	
	
	
	
}
