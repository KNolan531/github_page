/* Linked List and Stack Test Class 
 * by: Kevin Nolan 
 * 
 * This class tests the methods implemented in the LinkedList and Stack classes to make sure the data 
 * is being manipulated and inserted correctly. ArrayLists are used for testing purposes in the stack.  
 */

package listsTests;


import java.util.Scanner; 
import java.util.ArrayList;


public class ListsTest {
	
	
	private ArrayList<Integer> arr; 
	private int length; 
	
	
	public ListsTest() 
	{ 
		arr = new ArrayList<Integer>(10); 
		length = 10; 
		
	}
	
	public ListsTest(int length, ArrayList<Integer> test) 
	{ 
		arr = test; 
		this.length = length; 
		
	}
	
	
	public int getSum()
	{
		int sum = 0; 
		
		for(int i = 0; i < arr.size(); i++) 
			sum += arr.get(i);
		
		
	
		return sum; 
    }
	
	
	
	public static void main (String [] args) 
	{ 
		ArrayList<Integer> numbers = new ArrayList<Integer>(); 
		LinkedList list = new LinkedList(); 
		
		
		//Testing out LinkedList class 
		System.out.println(" Testing out the Linked List Class  \n"); 
		
		System.out.println("How many numbers would you like to add together? (1-10)");
		Scanner scan = new Scanner(System.in); 
		int size = scan.nextInt(); 
		int count = 0; 
		
		
		
		while (count < size) 
		{ 
			System.out.println("Please enter a number: "); 
			int input = scan.nextInt(); 
			list.add(input); 
			count++; 
			
		} 
		
		System.out.println("The numbers submitted are: "); 
		list.printList(); 
		
		System.out.println(); 
		System.out.println("The sum of these numbers are: " + list.getSum()); 
		System.out.println("\n  "); 
		System.out.println("Please enter a number to find in the List:"); 
		int number = scan.nextInt(); 
		
		if(list.findValue(number) != -1) 
			System.out.println("Number found! Located at index " + "" + list.findValue(number)); 
		else 
			System.out.println("Number not found!!!!!!"); 
		
		
		System.out.println("\n -------------------- "); 
		System.out.println(" Testing out the Stack Class "); 
		System.out.println("\n ---------------- "); 
		
		
				
		//Testing out the Stack Class 
		
		Stack s = new Stack(); 
try {
		s.push(8); 
		s.push(3); 
		s.push(2); 
		System.out.println("The original stack after 3 pushes: "); 
		s.printList(); 
		
		System.out.println("\n After popping 1 item off stack: "); 
		s.pop(); 
		s.printList(); 
		
		s.pop(); 
		System.out.println("\n Using peek after 1 pop: " + s.peek()); 
		
		s.pop(); 
		
		System.out.println("\n After popping off every item in stack and calling peek()..."); 
		s.peek(); 
	} 
catch(DataStructureException e) //error thrown if Stack is empty 
{ 
	System.out.println("Invalid action!!");
}

		
		
		
		
	}

	
}