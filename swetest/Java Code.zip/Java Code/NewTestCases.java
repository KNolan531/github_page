import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/* New Test Cases
 * by: Kevin Nolan 
 * --------------------------
 * This Test Suite implements all the new test cases derived 
 * in part 3 of the Project in the "Additional Test Cases" section. 
 * 
 * It implements the 3 test cases from the Syntax Coverage 
 * and the 5 test cases from the Graph Coverage. 
 * 
 */

public class NewTestCases 
{
	EncryptionHandling handler; 
	Message msg; 

	@Before
	public void setUp() 
	{
		msg = new Message(); 
		handler = new EncryptionHandling(); 
			
	}

	//Tests Mutant Test Case #1 - Changing alphabet >= �A� to <= �A�
	@Test
	public void testMutant1() 
	{
		msg.setMessage("K A"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		
		
		assertNotEquals("K A", encryptedMessage);
		
	}
	
	//Tests Mutant Test Case #2 - Changing alphabet >= �A� && to "||" 
	// by using ~ as a value to test to make sure the && is being used and not mutant "||"    
	// If ~ appears in actual output then that means mutant is not in the code. 
	@Test
	public void testMutant2() 
	{
		msg.setMessage("~ A"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		
		
		assertEquals("~ X", encryptedMessage);
	}
	
	//Tests Mutant Test Case #3 - Changing alphabet � shift to alphabet + shift. Verifying this != true 
	// by using K as a test value and making sure it does not get encrypted to + shift value of N 
	@Test
	public void testMutant3() 
	{
		msg.setMessage("K"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
				
		assertNotEquals("N", encryptedMessage);
	}
	
	
	//Tests Graph Coverage Case #1 - upper case value 'K' 
	@Test 
	public void testGraph1() 
	{ 
		msg.setMessage("K"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		String expectedEncryptedMessage = "H";
		
		assertEquals(expectedEncryptedMessage, encryptedMessage);
		
		
	}
	
	//Tests Graph Coverage Case #2 - lower case value 'k' 
	@Test 
	public void testGraph2() 
	{ 
		msg.setMessage("k"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		String expectedEncryptedMessage = "h";
		
		assertEquals(expectedEncryptedMessage, encryptedMessage);
		
	} 
	
	//Tests Graph Coverage Case #3 - upper case value 'A' 
	@Test 
	public void testGraph3() 
	{ 
		msg.setMessage("A"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		String expectedEncryptedMessage = "X";
		
		assertEquals(expectedEncryptedMessage, encryptedMessage);
			
	} 
	
	//Tests Graph Coverage Case #4 - lower case value 'a' 
	@Test 
	public void testGraph4() 
	{ 
		msg.setMessage("a"); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		String expectedEncryptedMessage = "x";
		
		assertEquals(expectedEncryptedMessage, encryptedMessage);
			
	} 
	
	
	
	//Tests Graph Coverage Case #5 - Blank space value 
	@Test 
	public void testGraph5() 
	{ 
		msg.setMessage(" "); 
		String decryptedMessage = msg.getMessage();
		
		String encryptedMessage = handler.caesarMessageEncryption(decryptedMessage); 
		String expectedEncryptedMessage = " ";
		
		assertEquals(expectedEncryptedMessage, encryptedMessage);
		
	}
	
	
	
	
	
	

}
