import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

public class FunctionalityTest 
{

	 /*
     * readMessageDataTest tests that message data was successfully read in from a text file to an array of size 3
     * Array index 0 = sender data, index 1 = recipient data, index 2 = Message
     */
    @Test
    public void readMessageDataTest()
    {
        System.out.println("Testing Read in Data Functionality");

        Message testMessage = new Message();
        testMessage.readMessageData(new File("testFile.txt"));
        String[] actualMessageData = testMessage.getMessageData();
        String[] expectedMessageData = {"Sender_Name", "Recipient_name", "Message"};
        assertEquals(expectedMessageData, actualMessageData);
    }

    /*
     * Tests functionality to write message data to a text file
     * Should be written in format of (<Sender>,<Recipient>,<Message>).
     */
    @Test
    public void writeMessageDataTest()
    {
        System.out.println("Testing Write Data Out Functionality");

        Message testMessage = new Message();
        String[] messageData =  testMessage.readMessageData(new File("testFile.txt"));
        boolean fileWritten = testMessage.writeMessageData(messageData);
        boolean expectedResult = true;
        assertEquals(expectedResult, fileWritten);
    }

    /*
     * Tests functionality to encrypt a message according to the Caesar Cipher Encryption Method
     */
    @Test
    public void caesarEncryptionMethodTest()
    {
        System.out.println("Testing Caesar Encryption Method Functionality");

        Message testMessage = new Message();
        testMessage.setMessage("TEST MESSAGE");
        String decryptedMessage = testMessage.getMessage();
               
        EncryptionHandling handle = new EncryptionHandling();
        String actualEncryptedMessage = handle.caesarMessageEncryption(decryptedMessage);
        String expectedEncryptedMessage = "QBPQ JBPPXDB";
        assertEquals(expectedEncryptedMessage, actualEncryptedMessage);
    }

    /*
     * Tests functionality to encrypt a message according to the Inverse Cipher Encryption Method
     */
    @Test
    public void inverseEncryptionMethodTest()
    {
        System.out.println("Testing Inverse Encryption Method Functionality");

        Message testMessage = new Message();
        testMessage.setMessage("TEST MESSAGE");
        String decryptedMessage = testMessage.getMessage();

        EncryptionHandling handle = new EncryptionHandling();
        String actualEncryptedMessage = handle.inverseMessageEncryption(decryptedMessage);
        String expectedEncryptedMessage = "GVHG NVHHZTV";
        assertEquals(expectedEncryptedMessage, actualEncryptedMessage);
    }

    /*
     * Tests functionality to decrypt a Caesar Cipher encrypted message.
     */
    @Test
    public void caesarMessageDecryptionTest()
    {
        System.out.println("Testing Caesar Decryption Method Functionality");

        Message testMessage = new Message();
        testMessage.setMessage("QBPQ JBPPXDB");
        String caesarEncryptedMessage = testMessage.getMessage();

        EncryptionHandling handle = new EncryptionHandling();
        String actualDecryptedMessage = handle.caesarMessageDecryption(caesarEncryptedMessage);
        String expectedDecryptedMessage = "TEST MESSAGE";
        assertEquals(expectedDecryptedMessage, actualDecryptedMessage);
    }

    /*
     * Tests functionality to decrypt an Inverse Cipher encrypted message.
     */
    @Test
    public void inverseMessageDecryptionTest()
    {
        System.out.println("Testing Inverse Decryption Method Functionality");

        Message testMessage = new Message();
        testMessage.setMessage("GVHG NVHHZTV");
        String inverseEncryptedMessage = testMessage.getMessage();

        EncryptionHandling handle = new EncryptionHandling();
        String actualDecryptedMessage = handle.inverseMessageDecryption(inverseEncryptedMessage);
        String expectedDecryptedMessage = "TEST MESSAGE";
        assertEquals(expectedDecryptedMessage, actualDecryptedMessage);
    }

}
