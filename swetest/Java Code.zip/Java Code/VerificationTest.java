import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

public class VerificationTest 
{

	/*
     * Tests that when reading a file that is empty
     * Message Data should also be empty
     */
	@Test
	public void emptyFileTest()
    {
        System.out.println("Testing that messageData is empty when reading in an empty file.");

        Message testMessage = new Message();
        testMessage.readMessageData(new File("emptyTestFile.txt"));
        String[] actualMessageData = testMessage.getMessageData();
        String[] expectedMessageData = {"", "", ""};
        assertEquals(expectedMessageData, actualMessageData);
    }
	

    /*
     * Tests senderData read in from file is accurate after read in process
     * If formatted ideally should be accurate (<Sender>,<Recipient>,<Message>)
     */
    @Test
    public void readInSenderDataIntegrityTest()
    {
        System.out.println("Testing Sender Data Integrity");

        Message testMessage = new Message();
        testMessage.readMessageData(new File("testFile.txt"));
        String actualSenderData = testMessage.getSender();
        String expectedSenderData = "Sender_Name";
        assertEquals(expectedSenderData, actualSenderData);
    }

    /*
     * Tests recipientData read in from file is accurate after read in process
     * If formatted ideally should be accurate (<Sender>,<Recipient>,<Message>)
     */
    @Test
    public void readInRecipientDataIntegrityTest()
    {
        System.out.println("Testing Recipient Data Integrity");

        Message testMessage = new Message();
        testMessage.readMessageData(new File("testFile.txt"));
        String actualRecipientData = testMessage.getRecipient();
        //System.out.println(testMessage.getRecipient()); 
        String expectedRecipientData = "Recipient_name";
        assertEquals(expectedRecipientData, actualRecipientData);
    }

    /*
     * Tests messageData read in from file is accurate after read in process
     * If formatted ideally should be accurate (<Sender>,<Recipient>,<Message>)
     */
    @Test
    public void readInMessageDataIntegrityTest()
    {
        System.out.println("Testing Message Data Integrity");
        
        Message testMessage = new Message();
        testMessage.readMessageData(new File("testFile.txt"));
        String actualMessageData = testMessage.getMessage();
        String expectedMessageData = "Message";
        assertEquals(expectedMessageData, actualMessageData);
    }
	

}
