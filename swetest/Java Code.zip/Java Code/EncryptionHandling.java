

public class EncryptionHandling
{
    private Message message;

    public EncryptionHandling() 
    {
    	message = new Message(); 
    }


    public String caesarMessageEncryption(String decryptedMessage)
    {
        String caesarEncryptedMessage = "";
        int shift = 3; 
        
        
        for(int i =0; i < decryptedMessage.length(); i++) 
        { 
        	char alphabet = decryptedMessage.charAt(i);
            
            if(alphabet >= 'a' && alphabet <= 'z')
            {
                
                alphabet = (char) (alphabet - shift);
            
                
                if(alphabet < 'a') 
                {
                   
                    alphabet = (char) (alphabet + 26);
                }
                
                caesarEncryptedMessage += alphabet;
                
            }    
               
            else if(alphabet >= 'A' && alphabet <= 'Z')
            {
             
                alphabet = (char) (alphabet - shift);
                
               
                if (alphabet < 'A') 
                {
                    
                    alphabet = (char) (alphabet + 26);
                }
                caesarEncryptedMessage += alphabet;            
            }
            else 
            {
            	caesarEncryptedMessage += alphabet;            
            } 
            
        }
        
        
        
        return caesarEncryptedMessage;
    }


    public String caesarMessageDecryption(String caesarEncryptedMessage)
    {
        String decryptedMessage = "";
        
        int shift = 3; 
        
        
        for(int i =0; i < caesarEncryptedMessage.length(); i++) 
        { 
        	char alphabet = caesarEncryptedMessage.charAt(i);
            
             
            if(alphabet >= 'a' && alphabet <= 'z') 
            {
             
             alphabet = (char) (alphabet + shift);
                   
             if(alphabet > 'z') 
             { 
            	 alphabet = (char) (alphabet - 26);
             }
             decryptedMessage += alphabet;
            }
            else if(alphabet >= 'A' && alphabet <= 'Z') 
            {
           
             alphabet = (char) (alphabet + shift);    
                                 
             if(alphabet > 'Z') 
             { 
            	 alphabet = (char) (alphabet - 26);
             }
             
              decryptedMessage += alphabet;
            }
            else 
            {
            	decryptedMessage += alphabet;   
            }
        }                
                
        return decryptedMessage;
    }


    public String inverseMessageEncryption(String decryptedMessage)
    {
        String inverseEncryptedMessage = "";
        int a = 25; 
        int b = 25; 
        
        for (int i = 0; i < decryptedMessage.length(); i++) 
        { 
        	if(decryptedMessage.charAt(i) >= 'A' && decryptedMessage.charAt(i) <= 'Z')
        	{
        		
        			inverseEncryptedMessage += 
                        (char) ((((a * (decryptedMessage.charAt(i) - 'A')) + b) % 26) + 'A'); 
        		 
        	} 
        	else if(decryptedMessage.charAt(i) >= 'a' && decryptedMessage.charAt(i) <= 'z')
        	{ 
        		inverseEncryptedMessage += 
                        (char) ((((a * (decryptedMessage.charAt(i) - 'a')) + b) % 26) + 'a');
        	}
        	else 
    		{ 
    			inverseEncryptedMessage += decryptedMessage.charAt(i); 
    		}  
        }  
         
        return inverseEncryptedMessage;
    }

    
    
    public String inverseMessageDecryption(String inverseEncryptedMessage)
    {
        String decryptedMessage = "";
        int a = 25; 
        int b = 25; 
        
        
        for (int i = 0; i < inverseEncryptedMessage.length(); i++)  
        { 
            
            if (inverseEncryptedMessage.charAt(i) >= 'A' && inverseEncryptedMessage.charAt(i) <= 'Z')  
            { 
            	decryptedMessage += (char) (((a *  
                        ((inverseEncryptedMessage.charAt(i) + 'A' - b)) % 26)) + 'A'); 
            } 
            else if (inverseEncryptedMessage.charAt(i) >= 'a' && inverseEncryptedMessage.charAt(i) <= 'z') 
            { 
            	decryptedMessage += (char) (((a *  
                        ((inverseEncryptedMessage.charAt(i) + 'a' - b)) % 26)) + 'z');
            }
            else  
            { 
                decryptedMessage += inverseEncryptedMessage.charAt(i); 
            } 
        }         
        
             
                
        return decryptedMessage;
        
    }

    
    
}
