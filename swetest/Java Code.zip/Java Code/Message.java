

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Message
{
    private String sender;
    private String recipient;
    private String message;
    private String[] messageData = new String[3];

    public Message() 
    {

    }

    public String getSender() 
    {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String[] getMessageData() {
        return messageData;
    }

    public void setMessage(String message) 
    {    	
        this.message = message;
    }

    public String[] readMessageData(File file)  
    {
    	Scanner scan;
    	
		try 
		{
		   scan = new Scanner(file);
		   scan.useDelimiter(","); 
    	if(scan.hasNext()) 
    	{
		   while(scan.hasNext()) 
		   {	 
    		sender = scan.next(); 
    		messageData[0] = sender; 
    		
    		recipient = scan.next(); 
    		messageData[1] = recipient; 
    		
    		message = scan.next(); 
    		messageData[2] = message; 
		   }
    	} 
    	else 
    	{  
    		sender = ""; 
    		messageData[0] = sender; 
    		
    		recipient = ""; 
    		messageData[1] = recipient; 
    		
    		message = ""; 
    		messageData[2] = message;
    		
    	}
		   
		} 
		catch (FileNotFoundException e) 
		{
			
			e.printStackTrace();
		}
		
        return messageData;
    }


    public boolean writeMessageData(String[] messageData)
    {
    	String content = ""; 
    	
    	for(int i = 0; i < messageData.length; i++) 
    		content += messageData[i] + ','; 
        
                
        try 
        {
        	FileWriter fileWriter = new FileWriter("output.txt");
			fileWriter.write(content);
			fileWriter.close();
		} 
        catch (IOException e) 
        {
			
			e.printStackTrace();
		}
        
        
        File f = new File("output.txt");
        try 
        {
        	Scanner scan = new Scanner(f);
        	scan.useDelimiter(",");  
        	
        	if(scan.hasNext()) 
        	{ 
        		if(scan.next().equals(messageData[0])) 
        			return true; 
        	}
        	else 
        		return false; 
        	
		} 
        catch (FileNotFoundException e) 
        {
			
			e.printStackTrace();
		} 
    	
        
    	return false; 
        
    }



}
