import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.*; 

/* Homework #3 - SWE 3643
 * by: Kevin Nolan 
 * ---------------------- 
 * Implements test suites compiled by Input Model in Part 1 of Homework 3. See PDF for 
 * test suite cases.
 */


public class LimitedListTest {
	
	static LimitedList list; 
	
	//Uses 8 as a default limit on all limited list instances 
	@BeforeClass 
	public static void setupList() 
	{ 
		  list = new LimitedList(8);  
	}
	
	
	
	//Resets the list to limit 8 before each test. 
	@Before 
	public void beforeEach() 
	{ 		
		list = new LimitedList(8);
		
	}
	
	//Constructor Test Case #1 - Tests constructor by testing to see if limit is 3 by checking isfull()  
	@Test 
	public void testConstructor() 
	{ 
		list = new LimitedList(3); 
		list.addToList(8, 3); 
		list.addToList(6, 2); 
		list.addToList(1, 4); 
		
		assertEquals(true, list.isFull()); 
	}
	
	
	//Constructor Test case #2 - Tests if constructor is given a value below 0
	@Test (expected = IllegalArgumentException.class)
	public void testConstructor2() 
	{
		list = new LimitedList(-2);  
				
	}
	
	//PeekAtList - Tests All 4 cases given in test suite. 
	@Test 
	public void testPeekAtList() 
	{ 
		//Tests case #2 - empty list 
		try 
		{ 
		assertEquals(2,list.peekAtList(2));
		} 
		catch( IllegalStateException e ) 
		{ 
			System.out.println("LimitedList.peekAtList - empty list");
			
		}
		
		//Tests case #1 - base case 
		list.addToList(88, 4); 
		assertEquals(88, list.peekAtList(4)); 
		
		
		//Tests case #4 - id = 0 
		try 
		{ 
		 assertEquals(88, list.peekAtList(0)); 
		} 
		catch( IllegalStateException e ) 
		{ 
			System.out.println("LimitedList.peekAtList - id: 0");
			
		}
		
		
		//Tests case #3 - id not found 
		try 
		{ 
		 assertEquals(88, list.peekAtList(6)); 
		} 
		catch( IllegalStateException e ) 
		{ 
			System.out.println("LimitedList.peekAtList - id not found");
			
		}
						
		
	}
	
	//AddToList - Tests all 4 cases given in test suite  
	@Test 
	public void testAddToList() 
	{ 
		//Test Case #1 - base case 
		list.addToList(88, 4); 
		assertEquals(88, list.peekAtList(4));
		
		//Test case #2 - full list 
		list = new LimitedList(1); 
		list.addToList(88, 4); 
		try 
		{ 
			list.addToList(84, 3);
			assertEquals(true, list.isFull());
		} 
		catch( IllegalStateException e ) 
		{ 
			System.out.println("LimitedList.AddToList - full list");
			
		}
		
		//Test Case #3 - id exists already 
		list = new LimitedList(2); 
		list.addToList(88, 3);
		try 
		{ 
			list.addToList(69, 3);
			
		} 
		catch( IllegalStateException e ) 
		{ 
			System.out.println("LimitedList.AddToList - id repeats");
			
		}
		
		//Test Case #4 - object is null 
		Object test = null; 
		
		try 
		{ 
			list.addToList(test, 3);
			
		} 
		catch( NullPointerException e ) 
		{ 
			System.out.println("LimitedList.AddToList - Null object value");
			
		}		 		
		
				
	}
	
	
	
	
	//removeFromList() - Tests all 5 cases from given test suite 
	@Test 
	public void test_removeFromList() 
	{ 
		//Test Case #5 - size = 0, item is not oldest 
		try 
		{ 
			list.removeFromList(); 
			
		} 
		catch( IllegalStateException e ) 
		{ 
			System.out.println("LimitedList.removeFromList - empty list");
			
		}
		
		//Test Case #1 - base case 
		list.addToList(88, 4); 
		list.addToList("Cookie", 1);
		list.addToList('a', 7); 
		list.addToList(44.8, 5);
		assertEquals(88,list.removeFromList());
		
		//Test Case #2 - string value, object is oldest 
		assertEquals("Cookie", list.removeFromList());
	
		//Test Case #3 - char value, object is oldest  
		assertEquals('a',list.removeFromList()); 
		
		//Test Case #4 - double value, object is oldest 
		assertEquals(44.8,list.removeFromList()); 
		
	}
	
	
	//isEmpty() - Tests all 2 cases from given test suite 
	@Test 
	public void test_isEmpty() 
	{ 
		//Test Case #2 - size = 0  
		assertEquals(true, list.isEmpty());
		
		
		//Test Case #1 - base case 
		list.addToList(88, 4); 
		list.addToList(27, 1); 
		assertEquals(false,list.isEmpty());
		
	}
	
	
	//isFull() - Tests all 3 cases from given test suite 
	@Test 
	public void test_isFull() 
	{ 
		//Test Case #1 - base case 
		list.addToList(88, 4); 
		list.addToList(27, 1); 
		assertEquals(false, list.isFull());
		
		//Test case #2 - size is 0, limit is 2 
		list = new LimitedList(2); 
		assertEquals(false, list.isFull()); 
		
		//Test case #3 - size is 2, limit is 2, isFull = true  
		list.addToList(88, 4); 
		list.addToList(27, 1); 
		assertEquals(true, list.isFull());
			
		
	}
	
	
	
}
