import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/* Homework #2
 * by: Kevin Nolan - SWE 3643
 * --------------------------------------
 * Implements Homework parts 2 + 3 that were derived from graph coverage. 
*/


public class PrintPrimesTest {
	
	PrintPrimes p; 
	
	
	//Re-Initializing the PrintPrimes object after each run thru
	@Before 
	public void setUp()
	{ 
		p = new PrintPrimes(); 
	}
	
	

	
	/* Test Case 2 - Implements test case from #2 in Homework 
	 *  Uses a test array to compare 2 arrays with printPrimes method. This 
	 *  is based off the while loop never activating due to n = 0. 
	 */
	@Test
	public void test2() 
	{
		int [] cookie = new int[1]; 
		cookie[0] = 2;
		
		assertArrayEquals(cookie,p.printPrimes(0, false)); 
		
				
	}
	
	/* Test Case 3a - Implements test case from #3a in Homework 
	 *  Uses a test array to compare 2 arrays with printPrimes method. Implements 
	 *  the test path created in #3a with inputs of n = 3, and showAll = true. 
	 */
	@Test 
	public void test3a() 
	{ 
		int [] cookie = new int[]{2,3,5}; 
		
		assertArrayEquals(cookie,p.printPrimes(3, true)); 
		
	}
	
	/* Test Case 3b - Implements test case from #3b in Homework 
	 *  Uses a test array to compare 2 arrays with printPrimes method. Implements 
	 *  the test path created in #3b with inputs of n = 3 and showAll = false.
	 */
	@Test 
	public void test3b() 
	{ 
		int [] cookie = new int[] {5}; 
					
		assertArrayEquals(cookie,p.printPrimes(3, false));		
	}
	
	

}
