import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PowerTest 
{ 
	Power p; 

		
	//Test Case #1 - Tests mutant case 1: if right > 0 instead of == 
	@Test
	public void testIfMutant() 
	{
		int ptest = p.power(2,3); 
		
		//changing right > 0 would make if statement true and return 1. 
		assertNotEquals(1,ptest); 
			
	}
	
	//Test Case #2 - Tests mutant case 2: i >= right instead of i <= right
	@Test 
	public void testForMutant() 
	{ 
		int ptest = p.power(2, 3); 
		
		// changing i <= right to i >= right will result in 2 >= 3 so  
		// the for loop will never execute, resulting in left (in this case 2) being returned
		assertNotEquals(2,ptest); 
		
	}
	
	//Test Case #3 - Tests mutant case 3: rslt = right instead of left 
	@Test 
	public void testVariableChangeMutant() 
	{ 
		int ptest = p.power(2, 3); 
		
		//changing rslt = right would make the for loop start with 3*2, then 6*2 = 12 
		assertNotEquals(12,ptest); 
		
	}
	
	//Test Case #4 - Tests mutant case 4: left = rslt * left instead of rslt = rslt * left 
	@Test 
	public void testIncrementChangeMutant() 
	{ 
		int ptest = p.power(2, 3); 
		
		//changing rslt = to left = would cause rslt to never change, thus resulting in rslt = 2.  
		assertNotEquals(2,ptest);
	}
	
	//Test Case #5 - Tests mutant case 5: rslt += 1 instead of rslt = 1 
	@Test 
	public void testAssignmentChangeMutant() 
	{ 
		int ptest = p.power(2, 0); //activate if statement to true 
		
		//changing rslt =1 to rslt += 1 would add 2 +1 = 3. 
		assertNotEquals(3,ptest); 
		
	}
	
	//Test Case #6 - Tests mutant case 6: rslt = rslt + left instead of * left 
	@Test 
	public void testOperatorChangeMutant() 
	{ 
		int ptest = p.power(2, 3); 
		
		//changing rlst * left to rslt + left would result in 2+2+2 = 6 
		assertNotEquals(6,ptest);
		
	}
	
	

}
